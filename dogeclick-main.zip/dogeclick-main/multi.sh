#Script is created by Neutralarmy
#All rights reserved ®

python doge.py +91.......... &
python doge.py +91.......... &
python doge.py +91...........

#Enter your no. with country code
#You can input unlimited numbers
#Using multiple accounts, directly effects your processor
